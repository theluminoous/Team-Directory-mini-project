-- =====================================================
-- Team Directory Database Setup
-- =====================================================

-- Create the Employees table
CREATE TABLE Employees (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Role VARCHAR(100) NOT NULL
);

-- Insert sample employee data with Pakistani names
INSERT INTO Employees (FirstName, LastName, Role) VALUES
('Ahmed', 'Khan', 'Software Engineer'),
('Fatima', 'Ali', 'Product Manager'),
('Hassan', 'Malik', 'UI/UX Designer'),
('Ayesha', 'Ahmed', 'DevOps Engineer'),
('Bilal', 'Hussain', 'Data Analyst'),
('Zainab', 'Raza', 'Marketing Manager'),
('Usman', 'Sheikh', 'Backend Developer'),
('Maryam', 'Tariq', 'QA Engineer');

-- =====================================================
-- SQLite Version (for file-based database)
-- =====================================================
-- If using SQLite, use this version instead:

-- CREATE TABLE Employees (
--     ID INTEGER PRIMARY KEY AUTOINCREMENT,
--     FirstName TEXT NOT NULL,
--     LastName TEXT NOT NULL,
--     Role TEXT NOT NULL
-- );

-- INSERT INTO Employees (FirstName, LastName, Role) VALUES
-- ('Ahmed', 'Khan', 'Software Engineer'),
-- ('Fatima', 'Ali', 'Product Manager'),
-- ('Hassan', 'Malik', 'UI/UX Designer'),
-- ('Ayesha', 'Ahmed', 'DevOps Engineer'),
-- ('Bilal', 'Hussain', 'Data Analyst'),
-- ('Zainab', 'Raza', 'Marketing Manager'),
-- ('Usman', 'Sheikh', 'Backend Developer'),
-- ('Maryam', 'Tariq', 'QA Engineer');

-- =====================================================
-- Verification Queries
-- =====================================================

-- View all employees
-- SELECT * FROM Employees ORDER BY LastName, FirstName;

-- Count total employees
-- SELECT COUNT(*) as TotalEmployees FROM Employees;

-- Search example
-- SELECT * FROM Employees 
-- WHERE FirstName LIKE '%Ahmed%' 
--    OR LastName LIKE '%Ahmed%' 
--    OR Role LIKE '%Engineer%';