import React, { useState, useEffect } from 'react';
import './App.css';
import { fetchEmployees } from './mockData';
const API_URL = 'http://127.0.0.1:62274/EmployeeAPI.cfc';

function App() {
  const [employees, setEmployees] = useState([]);
  const [filteredEmployees, setFilteredEmployees] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  // Load employees when app starts
  useEffect(() => {
    loadEmployees();
  }, []);

  // Filter employees when search term changes
  useEffect(() => {
    if (searchTerm === '') {
      setFilteredEmployees(employees);
    } else {
      const filtered = employees.filter(emp => 
        emp.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        emp.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        emp.role.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredEmployees(filtered);
    }
  }, [searchTerm, employees]);

  const loadEmployees = async () => {
    setLoading(true);
    const response = await fetchEmployees();
    if (response.success) {
      setEmployees(response.data);
      setFilteredEmployees(response.data);
    }
    setLoading(false);
  };

  return (
    <div className="container">
      <header className="header">
        <h1>Team Directory</h1>
        <p>Find and connect with team members</p>
      </header>

      <div className="search-section">
        <input
          type="text"
          className="search-input"
          placeholder="Search by name or role..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <main className="main-content">
        {loading ? (
          <div className="loading">Loading employees...</div>
        ) : (
          <>
            <div className="results-count">
              Showing {filteredEmployees.length} of {employees.length} employees
            </div>
            
            <table className="employee-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Role</th>
                  <th>ID</th>
                </tr>
              </thead>
              <tbody>
                {filteredEmployees.length > 0 ? (
                  filteredEmployees.map(employee => (
                    <tr key={employee.id}>
                      <td className="name-cell">
                        <div className="avatar">
                          {employee.firstName[0]}{employee.lastName[0]}
                        </div>
                        <span>{employee.firstName} {employee.lastName}</span>
                      </td>
                      <td>{employee.role}</td>
                      <td className="id-cell">#{employee.id}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="3" className="no-results">
                      No employees found matching "{searchTerm}"
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </>
        )}
      </main>
    </div>
  );
}

export default App;