import React from 'react';
import './EmployeeCard.css';

// This component displays ONE employee as a card
// It receives employee data as a "prop"
function EmployeeCard({ employee }) {
  // Create initials from first and last name
  const initials = `${employee.firstName[0]}${employee.lastName[0]}`;
  
  return (
    <div className="employee-card">
      {/* Avatar circle with initials */}
      <div className="employee-avatar">
        {initials}
      </div>
      
      {/* Employee information */}
      <div className="employee-info">
        <h3 className="employee-name">
          {employee.firstName} {employee.lastName}
        </h3>
        <p className="employee-role">{employee.role}</p>
        <p className="employee-id">ID: {employee.id}</p>
      </div>
    </div>
  );
}

export default EmployeeCard;