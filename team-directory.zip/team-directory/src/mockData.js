// Mock database with Pakistani employee names
// In real project, this data comes from ColdFusion API

export const mockEmployees = [
  {
    id: 1,
    firstName: "Ahmed",
    lastName: "Khan",
    role: "Software Engineer"
  },
  {
    id: 2,
    firstName: "Fatima",
    lastName: "Ali",
    role: "Product Manager"
  },
  {
    id: 3,
    firstName: "Hassan",
    lastName: "Malik",
    role: "UI/UX Designer"
  },
  {
    id: 4,
    firstName: "Ayesha",
    lastName: "Ahmed",
    role: "DevOps Engineer"
  },
  {
    id: 5,
    firstName: "Bilal",
    lastName: "Hussain",
    role: "Data Analyst"
  },
  {
    id: 6,
    firstName: "Zainab",
    lastName: "Raza",
    role: "Marketing Manager"
  },
  {
    id: 7,
    firstName: "Usman",
    lastName: "Sheikh",
    role: "Backend Developer"
  },
  {
    id: 8,
    firstName: "Maryam",
    lastName: "Tariq",
    role: "QA Engineer"
  }
];

// This simulates an API call
// It pretends to fetch data like a real API would
export const fetchEmployees = () => {
  return new Promise((resolve) => {
    // Wait 500ms to simulate network delay
    setTimeout(() => {
      resolve({
        success: true,
        data: mockEmployees,
        count: mockEmployees.length
      });
    }, 500);
  });
};

// This simulates searching employees
export const searchEmployees = (searchTerm) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const filtered = mockEmployees.filter(employee => 
        employee.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        employee.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        employee.role.toLowerCase().includes(searchTerm.toLowerCase())
      );
      
      resolve({
        success: true,
        data: filtered,
        count: filtered.length
      });
    }, 500);
  });
};